
public class Main {

    public static void main(String[] args) throws Exception {
        UserInterface ui = new UserInterface();
        System.out.println("Hello giatay!");
    }
}
